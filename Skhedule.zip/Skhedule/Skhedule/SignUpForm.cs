﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Skhedule
{
    public partial class SignUpForm : Form
    {
        UserTable user;
        UserTable newUser;
        public enum Mode { Insert, Edit }

        public SignUpForm()
        {
            InitializeComponent();
            btnSignup.Text = "SIGN UP";
        }
        public SignUpForm(string username, string password)
        {
            InitializeComponent();
            user = new UserTable
            {
                userUname = username,
                userPassword = password
            };
            tbUssername.Text = username;
            tbPassword.Text = password;
            btnSignup.Text = "SIGN UP";
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            if (tbUssername.Text == "" || tbPassword.Text == "" || tbConfirm.Text == "")
            {
                MessageBox.Show("Ketiga input tidak boleh kosong!");
            }

            if (tbPassword.Text != tbConfirm.Text)
            {
                MessageBox.Show("Kedua password harus sama");
            }

            using (var db = new SkheduleDBEntities())
            {
                newUser = new UserTable
                {
                    userUname = tbUssername.Text,
                    userPassword = tbPassword.Text,
                };
                db.UserTables.Add(newUser);
                db.SaveChanges();
                MessageBox.Show("Sign Up Berhasil");
                Close();
            }
        }
    }
}
